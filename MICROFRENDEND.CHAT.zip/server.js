// -----------------------------
// 🚀 Dranzo Assistant Server (Gemini-only, JSON responses)
// -----------------------------
import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import cors from "cors";
import dotenv from "dotenv";
import multer from "multer";
import { fileTypeFromBuffer } from "file-type";
import { GoogleGenerativeAI } from "@google/generative-ai";
import { getDocument } from "pdfjs-dist/legacy/build/pdf.mjs";

console.log("Executing server.js...");
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// -----------------------------
// ⚙️ Express Setup
// -----------------------------
const app = express();
app.use(cors());
app.use(express.json());
app.use("/", express.static(path.join(__dirname, "public")));

// -----------------------------
// 📦 Upload setup (memory)
// -----------------------------
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 20 * 1024 * 1024 }, // 20 MB
});

// -----------------------------
// 🧰 Helpers
// -----------------------------
async function extractPdfTextFromBuffer(buffer) {
  const data = new Uint8Array(buffer);
  const pdf = await getDocument({ data }).promise;
  let text = "";
  const maxPages = Math.min(pdf.numPages, 50);
  for (let i = 1; i <= maxPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    text += content.items.map(it => it.str).join(" ") + "\n\n";
    if (text.length > 180000) break;
  }
  return text;
}

// Simple candidate extractors (optional context for Gemini)
const RX = {
  PAN: /[A-Z]{5}[0-9]{4}[A-Z]/g,
  GSTIN: /\b\d{2}[A-Z]{5}\d{4}[A-Z][A-Z0-9][Z]\d\b/g,
  IFSC: /\b[A-Z]{4}0[A-Z0-9]{6}\b/g,
  AADHAAR: /\b\d{4}\s?\d{4}\s?\d{4}\b/g
};
function extractCandidates(str="") {
  const up = String(str).toUpperCase();
  const out = {};
  for (const k of Object.keys(RX)) {
    const m = up.match(RX[k]) || [];
    out[k] = [...new Set(m)];
  }
  return out;
}

async function callGemini(model, partsOrString) {
  try {
    if (typeof partsOrString === "string") {
      const r = await model.generateContent(partsOrString);
      return { ok: true, answer: r.response.text() };
    }
    const body = Array.isArray(partsOrString) ? { contents: partsOrString } : partsOrString;
    const r = await model.generateContent(body);
    return { ok: true, answer: r.response.text() };
  } catch (e) {
    return { ok: false, error: e?.message || String(e) };
  }
}

function buildFullDocPrompt({ basePrompt, text, candidates }) {
  // Ask Gemini to analyze ALL data, not just PAN, and include summary + mistakes + fixes + rewrites.
  const { PAN=[], GSTIN=[], IFSC=[], AADHAAR=[] } = candidates || {};
  return [
    {
      role: "user",
      parts: [
        {
          text:
`${basePrompt}

Detected candidate identifiers (regex-based, may include false positives):
- PAN: ${PAN.length ? PAN.join(", ") : "(none)"}
- GSTIN: ${GSTIN.length ? GSTIN.join(", ") : "(none)"}
- IFSC: ${IFSC.length ? IFSC.join(", ") : "(none)"}
- Aadhaar: ${AADHAAR.length ? AADHAAR.join(", ") : "(none)"}

TASKS:
1) Give a concise overall SUMMARY (2–4 sentences).
2) VALIDATE data fields you can infer (PAN/GSTIN/IFSC/Aadhaar formats, dates, totals, invoice numbers, codes, etc.). Note mismatches, casing/spacing errors, or likely typos.
3) LIST all MISTAKES/ISSUES clearly (bullet points).
4) Provide PRACTICAL FIXES. Where helpful, REWRITE the faulty lines/sections verbatim in improved form.
5) If there is code/structured content, show corrected SNIPPETS.
6) Keep the answer crisp and action-oriented.

Document text:
${text}`
        }
      ]
    }
  ];
}

// -----------------------------
// 🧠 Gemini Initialization
// -----------------------------
const PREFERRED_MODEL = "gemini-2.5-flash";
const FALLBACK_MODEL = "gemini-1.5-pro";

let geminiModel = null;
async function initGemini(){
  if (!process.env.GEMINI_API_KEY) {
    console.warn("⚠️ GEMINI_API_KEY not found in .env");
    return;
  }
  try{
    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
    try {
      geminiModel = genAI.getGenerativeModel({
        model: PREFERRED_MODEL,
        generationConfig: { temperature: 0.7, maxOutputTokens: 2048 }
      });
      await geminiModel.generateContent("ping");
      console.log(`✅ Gemini initialized (${PREFERRED_MODEL})`);
    } catch (e) {
      console.warn(`⚠️ ${PREFERRED_MODEL} failed (${e?.message}). Trying ${FALLBACK_MODEL}...`);
      geminiModel = genAI.getGenerativeModel({
        model: FALLBACK_MODEL,
        generationConfig: { temperature: 0.7, maxOutputTokens: 2048 }
      });
      await geminiModel.generateContent("ping");
      console.log(`✅ Gemini initialized (${FALLBACK_MODEL})`);
    }
  }catch(e){
    console.error("❌ Gemini init failed:", e?.message || e);
  }
}
await initGemini();

// -----------------------------
// 💬 Chat API — returns JSON
// -----------------------------
app.post("/api/chat", async (req, res) => {
  try {
    if (!geminiModel) return res.status(503).json({ ok:false, error:"Gemini not available" });
    const { message } = req.body || {};
    if (!message) return res.status(400).json({ ok:false, error:"Message is required" });

    const out = await callGemini(geminiModel, message);
    if (!out.ok) return res.status(502).json({ ok:false, error: out.error });
    return res.json(out);
  } catch (err) {
    console.error("❌ Gemini chat error:", err?.message || err);
    return res.status(502).json({ ok:false, error:"No response from Gemini. Please try again later." });
  }
});

// -----------------------------
// 📂 Analyze API — PDF/Image/Text — returns JSON
// -----------------------------
app.post("/api/analyze", upload.single("file"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ ok:false, error:"No file uploaded" });
    if (!geminiModel) return res.status(503).json({ ok:false, error:"Gemini not available" });

    const detected = await fileTypeFromBuffer(req.file.buffer);
    const mime = detected?.mime || req.file.mimetype || "application/octet-stream";
    const userPrompt = (req.body && req.body.prompt) || "";
    const basePrompt =
      userPrompt ||
      `Analyze ALL data (not only PAN). Provide summary, list mistakes, and concrete fixes; rewrite incorrect lines/sections where helpful.`;

    // PDF → extract → candidates → Gemini full analysis
    if (mime === "application/pdf") {
      const raw = await extractPdfTextFromBuffer(req.file.buffer);
      const text = (raw || "").slice(0, 180000);
      if (!text) return res.status(400).json({ ok:false, error:"Could not extract text from PDF." });

      const candidates = extractCandidates(text);
      const out = await callGemini(geminiModel, buildFullDocPrompt({ basePrompt, text, candidates }));
      if (!out.ok) return res.status(502).json({ ok:false, error: out.error });
      return res.json({ ok:true, answer: out.answer });
    }

    // Image → send inline + general analysis request
    if (mime.startsWith("image/")) {
      const b64 = req.file.buffer.toString("base64");
      const out = await callGemini(geminiModel, [
        {
          role: "user",
          parts: [
            { inlineData: { mimeType: mime, data: b64 } },
            { text: `${basePrompt}\nDescribe briefly, list issues, and provide fixes/rewrites.` },
          ],
        },
      ]);
      if (!out.ok) return res.status(502).json({ ok:false, error: out.error });
      return res.json(out);
    }

    // Treat others as text
    const asText = req.file.buffer.toString("utf-8").slice(0, 180000);
    if (!asText) return res.status(400).json({ ok:false, error:"Unsupported or empty file." });

    const candidates = extractCandidates(asText);
    const out = await callGemini(geminiModel, buildFullDocPrompt({ basePrompt, text: asText, candidates }));
    if (!out.ok) return res.status(502).json({ ok:false, error: out.error });
    return res.json({ ok:true, answer: out.answer });
  } catch (err) {
    console.error("❌ Analyze error:", err?.message || err);
    return res.status(500).json({ ok:false, error:"Error analyzing file." });
  }
});

// -----------------------------
// 🩺 Health
// -----------------------------
app.get("/api/health", (req, res) =>
  res.json({ ok: true, modelReady: !!geminiModel, port: process.env.PORT || 5003 })
);

// -----------------------------
// 🚀 Start Express Server (with port fallback)
// -----------------------------
const port = parseInt(process.env.PORT || "5003", 10);
const MAX_PORT_ATTEMPTS = 10;

function startServer(p, attempts = 0) {
  if (attempts >= MAX_PORT_ATTEMPTS) {
    console.error("❌ Maximum port attempts reached. Exiting.");
    process.exit(1);
  }
  const server = app.listen(p, () => console.log(`🚀 Server running at http://localhost:${p}`));
  server.on("error", (err) => {
    if (err.code === "EADDRINUSE") {
      console.warn(`⚠️ Port ${p} busy. Trying ${p + 1}...`);
      startServer(p + 1, attempts + 1);
    } else {
      console.error("❌ Server error:", err);
      process.exit(1);
    }
  });
}
startServer(port);
