(function(){
  const root = document.getElementById('dranzo-widget');

  const fab = document.createElement('button');
const fabImg = document.createElement('img');
fabImg.src = 'assets/dranzo-logo.png';
fabImg.alt = 'Dranzo';
fabImg.style.width = '80%';
fabImg.style.height = '80%';
fabImg.style.objectFit = 'contain';
fabImg.style.borderRadius = '50%';
fabImg.style.padding = '10%';
fabImg.style.backgroundColor = '#fff';
fabImg.style.boxShadow = '0 4px 8px rgba(0,0,0,0.2)';
fab.appendChild(fabImg);



  fab.className = 'dranzo-fab';
  fab.title = 'Dranzo Chat';
  
  root.appendChild(fab);

  const panel = document.createElement('div');
  panel.className = 'dranzo-panel';
  panel.innerHTML = `
    <div class="dranzo-header"><img src="assets/dranzo-logo.png" alt="Dranzo Logo" style="height:40px;margin-right:10px;"><div class="title">Dranzo Chat</div></div>
    <div class="dranzo-chat" id="dz-chat"></div>
    <div class="dranzo-controls">
      <label class="attach">📎 <input id="dz-file" type="file" accept="image/*,.pdf,.txt"></label>
      <input id="dz-input" type="text" placeholder="Type a message…" />
      <button id="dz-send" class="send">Send</button>
    </div>
  `;
  root.appendChild(panel);

  fab.onclick = () => {
    panel.style.display = panel.style.display === 'block' ? 'none' : 'block';
  };

  const chat = panel.querySelector('#dz-chat');
  const input = panel.querySelector('#dz-input');
  const file = panel.querySelector('#dz-file');
  const send = panel.querySelector('#dz-send');

  const messages = [
    { role: 'assistant', content: 'Hi! I am <b>Dranzo Chat</b>. Ask me anything or upload an image/PDF — I’ll analyze automatically.' }
  ];

  function render(){
    chat.innerHTML = '';
    messages.forEach(m => {
      const row = document.createElement('div');
      row.className = 'msg ' + m.role;
      const bubble = document.createElement('div');
      bubble.className = 'bubble';
      bubble.innerHTML = m.content;
      row.appendChild(bubble);
      chat.appendChild(row);
    });
    chat.scrollTop = chat.scrollHeight;
  }
  render();

  async function sendMsg(){
    const text = input.value.trim();
    if (!text) return;
    messages.push({ role:'user', content: text });
    render();
    input.value = '';
    try{
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text })
      });
      const data = await res.json(); // server returns JSON
      messages.push({ role:'assistant', content: data.ok ? data.answer : ('Error: ' + data.error) });
    }catch(e){
      messages.push({ role:'assistant', content: 'Error: ' + String(e) });
    }finally{
      render();
    }
  }

  // 🔁 Auto-analyze on file select (no Analyze button)
  async function autoAnalyze(){
    const f = file.files && file.files[0];
    if (!f) return;
    const prompt = input.value.trim(); // optional user hint
    messages.push({ role:'user', content: `📎 ${f.name}${prompt ? '<br>'+prompt : ''}` });
    render();
    input.value = '';
    try{
      const form = new FormData();
      form.append('file', f);
      form.append('prompt', prompt || '');
      const res = await fetch('/api/analyze', { method: 'POST', body: form });
      const data = await res.json(); // server returns JSON
      messages.push({ role:'assistant', content: data.ok ? data.answer : ('Error: ' + data.error) });
    }catch(e){
      messages.push({ role:'assistant', content: 'Error: ' + String(e) });
    }finally{
      file.value = '';
      render();
    }
  }

  // drag & drop over the chat area (optional but handy)
  chat.addEventListener('dragover', e => { e.preventDefault(); });
  chat.addEventListener('drop', e => {
    e.preventDefault();
    const f = e.dataTransfer.files && e.dataTransfer.files[0];
    if (!f) return;
    file.files = e.dataTransfer.files; // set to input for consistency
    autoAnalyze();
  });

  // events
  send.onclick = sendMsg;
  input.addEventListener('keydown', e => { if (e.key === 'Enter') sendMsg(); });
  file.addEventListener('change', autoAnalyze); // 👈 auto-analyze on selection
})();
